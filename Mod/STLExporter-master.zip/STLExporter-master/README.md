# STLExporter
a paracraft plugin which can export bmax file to stl file
